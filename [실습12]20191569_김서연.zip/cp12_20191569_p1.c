#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define bool int
#define true  1
#define false 0

typedef struct {
	int count;
	struct node* top;
} STACK;

typedef struct node {
	char data;
	struct node* link;
} STACK_NODE;

bool Push(STACK* pStack, char parenthese) {
	STACK_NODE* pNew;
	bool success;

	pNew = (STACK_NODE*)malloc(sizeof(STACK_NODE));

	if (!pNew)
		success = false;
	else {
		pNew->data = parenthese;
		pNew->link = pStack->top;
		pStack->top = pNew;
		pStack->count++;
		success = true;
	}
	// whether success or not
	/* TODO5. create new node */
	return success;
}// Push

bool Pop(STACK* pStack, char* parenthese) {
	STACK_NODE* pDlt;
	bool success;

	if (pStack->top == NULL) {
		success = false;
		pStack->count--;
	}
	
	else {
		*parenthese = pStack->top->data;
		pDlt = pStack->top;
		pStack->top = pDlt->link;
		pStack->count--;
		success = true;

		free(pDlt);
	}
	/* TODO6. stack pop operation */
	return success;
} // Pop

bool isOpenParenthese(char c) {
	if (c == '(' || c == '[' || c == '{')
		return true;
	else
		return false;
}

bool isCloseParenthese(char c) {
	if (c == ')' || c == ']' || c == '}')
		return true;
	else
		return false;
	/* TODO5. */
}

int main(void) {
	char equ[100];
	int length;
	int i = 0;
	STACK* pStack;

	pStack = (STACK*)malloc(sizeof(STACK));
	pStack->top = NULL;
	pStack->count = 0;
	/* TODO1. stack memory allocation&initialization */


	scanf("%s", equ);
	length = strlen(equ);
	char temp;
	for (i = 0; i < length; ++i) {
		temp = equ[i];
		if (isOpenParenthese(equ[i]) == 1) {
			Push(pStack, equ[i]);
		}
		else if (isCloseParenthese(equ[i]) == 1) {
			Pop(pStack, &equ[i]);
			if (temp == ')') {
				if (equ[i] != '(') {
					printf("Unmatchd Parentheses!\n");
					return 0;
				}
			}
			if (temp == ']') {
				if (equ[i] != '[') {
					printf("Unmatchd Parentheses!\n");
					return 0;
				}
			}
			if (temp == '}') {
				if (equ[i] != '{') {
					printf("Unmatchd Parentheses!\n");
					return 0;
				}
			}
		}
		/* TODO2. Parentheses check for equ[i]
		use above functions
		*/

	}
	if (pStack->count == 0) {
		printf("Matched Parentheses!\n");
	}
	else {
		printf("Unmatched Parentheses!\n");
	}
	return 0;
}
