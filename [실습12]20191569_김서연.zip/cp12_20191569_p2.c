#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct node {
	char command[10];
	struct node* next;
} QUEUE_NODE;
typedef struct {
	QUEUE_NODE* front;
	int count;
	QUEUE_NODE* rear;
} QUEUE;

int CheckCommand(char* command);
void EnqueueCommand(QUEUE* pQueue, char* dataIn);
int DequeuePrint(QUEUE* pQueue, char* dataOut);

int main(void) {

	char command[10];
	char printData[10];

	QUEUE* pQueue;
	pQueue = (QUEUE*)malloc(sizeof(QUEUE));
	pQueue->front = NULL;
	pQueue->rear = NULL;
	pQueue->count = 0;
	/* TODO1. Queue memory allocation & initialization */

	int temp;
	while (1) {
		printf(">>");
		scanf("%s", command);
		if (CheckCommand(command) == 1) {
			if (strcmp(command,"q")==0 || strcmp(command,"quit")==0) {
				break;
			}
			else if (strcmp(command,"h")==0 || strcmp(command,"history")==0) {
				while (1) {
					temp = DequeuePrint(pQueue, printData);

					if (temp == 0) break;
					else
						printf("%s\n", printData);
				}

			}
			else {
				EnqueueCommand(pQueue, command);
				printf("%s\n", command);
			}
		}
		/* TODO2.
		1) in case of "q" or "quit"
		2) in case of "h" or "history"
		3) in case of other valid commands
		*/
	}
	return 0;
}
int CheckCommand(char* command) {
	if (strcmp(command,"help")==0 || strcmp(command, "dir") == 0|| strcmp(command, "mkdir") == 0 || strcmp(command, "cd") == 0 || strcmp(command, "history") == 0 || strcmp(command, "h") == 0 || strcmp(command, "quit") == 0 || strcmp(command, "q") == 0)
		return 1;
	else
		return 0;
}
void EnqueueCommand(QUEUE* pQueue, char* dataIn) {
	QUEUE_NODE* newPtr;

	newPtr = (QUEUE_NODE*)malloc(sizeof(QUEUE_NODE));
	strcpy(newPtr->command,dataIn);
	newPtr->next = NULL;

	if (pQueue->count == 0) {
		pQueue->front = newPtr;
		pQueue->rear = newPtr;
	}
	else {
		pQueue->rear->next = newPtr;
		pQueue->rear = newPtr;
	}
	pQueue->count++;
	/* TODO5. create new node */

}
int DequeuePrint(QUEUE* pQueue, char* dataOut) {
	QUEUE_NODE* deleteLoc;

	if (pQueue->count == 0) {
		//pQueue->count--;
		return 0;
	}
	else if (pQueue->count == 1) {
		strcpy(dataOut,pQueue->front->command);
		deleteLoc = pQueue->front;
		pQueue->front = pQueue->rear = NULL;
		pQueue->count--;
		free(deleteLoc);
	}
	else {
		strcpy(dataOut,pQueue->front->command);
		deleteLoc = pQueue->front;
		pQueue->front = deleteLoc->next;
		pQueue->count--;
		free(deleteLoc);
	}
	/* TODO6.
	1) dequeue & write data to 'dataOut'
	2) 1 if success, 0 if not
	3) do not print here
	*/
	return 1;
}
