#include <stdio.h>
void swap(char**str1, char**str2);
int main(void) {
	char *str1 = "My name is Kim Seo Yeon";
	char *str2 = "Student id is 20191569";

	printf("Before swapping\n\n");
	printf("str1 = %s\nstr2 = %s\n\n", str1, str2);

	swap(&str1, &str2);

	printf("After swapping\n\n");
	printf("str1 = %s\nstr2 = %s\n", str1, str2);
}
void swap(char**str1, char**str2) {
	char* temp;
	temp = *str1;

	*str1 = *str2;
	*str2 = temp;
}