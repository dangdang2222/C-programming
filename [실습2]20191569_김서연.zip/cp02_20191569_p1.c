#include <stdio.h>

void* min(void *ptr1, void* ptr2, char option);
int main(void) {
	char op;
	int n1, n2;
	float f1, f2;

	void* ptr1, *ptr2, *result;

	printf("Enter the type of numbers: ");
	scanf("%c", &op);

	if (op == 'i') {
		printf("Enter the 1st number : ");
		scanf("%d", &n1);
		ptr1 = &n1;
		printf("Enter the 2nd number : ");
		scanf("%d", &n2);
		ptr2 = &n2;

		result = min(ptr1, ptr2, op);
		
		printf("\n\nminimum value is %d\n",*(int*)result);
	}
	else if (op == 'f') {
		printf("Enter the 1st number : ");
		scanf("%f", &f1);
		ptr1 = &f1;
		printf("Enter the 2nd number : ");
		scanf("%f", &f2);
		ptr2 = &f2;

		result = min(ptr1, ptr2, op);
	
		printf("\n\nminimum value is %.2f\n", *(float*)result);
	}
}
void* min(void *ptr1, void* ptr2, char option) {
	if (option == 'i') {
		if (*(int*)ptr1 > *(int*)ptr2)
			return ptr2;
		else
			return ptr1;
	}
	if (option == 'f') {
		if (*(float*)ptr1 > *(float*)ptr2)
			return ptr2;
		else
			return ptr1;
	}
}