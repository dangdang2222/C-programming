#include <stdio.h>

void calGcdLcm(int num1, int num2, int*gcd, int*lcm);
int main(void) {

	int n1, n2;
	int gcd, lcm;

	printf("Enter the 1st number : ");
	scanf("%d", &n1);
	printf("Enter the 2nd number : ");
	scanf("%d", &n2);

	calGcdLcm(n1, n2, &gcd, &lcm);

	printf("\n\n");
	printf("GCD of %d and %d is %d\n", n1, n2, gcd);
	printf("LCM of %d and %d is %d", n1, n2, lcm);
}
void calGcdLcm(int num1, int num2, int*gcd, int*lcm) {
	int a, b;
	int tempa = num1;
	int tempb = num2;
	while (1) {
		a = num1;
		b = num2;

		num1 = num2;
		num2 = a % b;

		if (num2 == 0) {
			*gcd = b;
			break;
		}
	}

	*lcm = (tempa*tempb) / *gcd;
}
