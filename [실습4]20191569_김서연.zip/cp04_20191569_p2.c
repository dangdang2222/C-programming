#include <stdio.h>
void selection_sort(int*array, int* pwalk1, int*pwalk2, int*pwalk3);
int main(void) {
	int data_array[4][8] = { {838,758,113,515,51,627,10,419},{212,86,749,767,84,60,225,543},{89,183,137,566,966,978,495,311},{367,54,31,145,882,736,524,505} };
	int a, b, c;

	printf("Before sorting\n");
	for (int i = 0; i < 4; i++) {
		for (int j = 0; j < 8; j++) {
			printf("%4d", data_array[i][j]);
		}
		printf("\n");
	}
	int p;
	while (1) {
		printf("Enter the row index (0~3) : ");
		scanf("%d", &p);

		if (p == -1) break;
		if (p < 0 || p>3) continue;

		selection_sort(data_array[p], &a, &b, &c);
		printf(" %d_th row after sorting\n  ",p);
		for (int j = 0; j < 8; j++) {
			printf("%d  ", data_array[p][j]);
		}
		printf("\n");
	}
	printf("\n");
	printf("After sorting\n");
	for (int i = 0; i < 4; i++) {
		for (int j = 0; j < 8; j++) {
			printf("%4d", data_array[i][j]);
		}
		printf("\n");
	}
	printf("----------------------------\n");
}
void selection_sort(int*array, int* pwalk1, int*pwalk2, int*pwalk3) {
	int temp;

	int cnt = 0;
	int ccnt = 0;
	for (pwalk1 = array; cnt<7; pwalk1++) {
		ccnt = 0;
		pwalk3 = pwalk1 + 1;
		for (pwalk2 = pwalk1 + 1; ccnt + cnt < 7; pwalk2++) {
			if (*pwalk3 > *pwalk2)
				pwalk3 = pwalk2;
			ccnt++;
		}
		if (*pwalk3 < *pwalk1) {
			temp = *pwalk3;
			*pwalk3 = *pwalk1;
			*pwalk1 = temp;
		}
		cnt++;
	}
}
