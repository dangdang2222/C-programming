#include <stdio.h>

void rounding_off(double *row, int n);
void add_matrix(double *left_row, double *right_row, double *result_row, int n);
int main(void) {
	double left[5][5] = { {1.4,9.8,2.5,1.1,5.7},{1.2,2.1,8.7,1.9,7.5},{3.2,3.1,3.7,2.7,3.9},{6,8,4.6,0,6.3},{9.4,6.6,1.4,6.7,8.9} };
	double right[5][5] = { {7,4.8,4.5,7.1,2.6},{4.3,2.6,5.6,8.2,9.4},{1.3,4.1,8.4,7.9,1.8},{5.2,6.2,8.5,9,1.8},{3.4,0.6,8.9,3.8,2.1} };
	double result[5][5] = { 0, };

	for (int i = 0; i < 5; i++) {
		rounding_off(*(left+i), 5);
		rounding_off(*(right + i), 5);
	}

	for (int i = 0; i < 5; i++) {
		add_matrix(*(left + i), *(right + i), *(result + i),5);
	}

	printf("   Left\t\t\t  Right\t\t\t  Result\t\t\t\n");
	for (int i = 0; i < 5; i++) {
		for (int j = 0; j < 5; j++) {
			printf("%4d", (int)(*(*(left+i)+j)));
		}
		printf("\t");
		for (int j = 0; j < 5; j++) {
			printf("%4d", (int)(*(*(right + i) + j)));
		}
		printf("\t");
		for (int j = 0; j < 5; j++) {
			printf("%4d", (int)(*(*(result + i) + j)));
		}
		printf("\n");
	}
}
void rounding_off(double *row, int n) {
	for (int i = 0; i < n; i++) {
		if (*(row + i) - (int)(*(row + i)) >= 0.5)
			*(row + i) = (int)(*(row + i)) + 1;
		else
			*(row + i) = (int)(*(row + i));
	}
}
void add_matrix(double *left_row, double *right_row, double *result_row, int n) {
	for (int i = 0; i < n; i++) {
		*(result_row+i) = *(left_row+i) + *(right_row+i);
	}
}