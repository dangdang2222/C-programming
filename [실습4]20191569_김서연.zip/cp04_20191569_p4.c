#include <stdio.h>
#include <stdlib.h>
int* calculate_next(int* Pascal_tr, int current_level);
int main(void) {
	printf("Input the level of Pascal's triangle : ");
	int n;
	scanf("%d", &n);

	int* Pascal_tr = (int*)malloc(sizeof(int) * 1);
	Pascal_tr[0] = 1;

	for (int i = 1; i <= n; i++) {
		if (i == n) printf(" Final Level = %d, ", i);
		else printf("Level Number = %d, ", i);
		for (int k = 0; k < i; k++) {
			printf("%d ", Pascal_tr[k]);
		}
		printf("\n");
		Pascal_tr = calculate_next(Pascal_tr, i);
	}
	free(Pascal_tr);
}
int* calculate_next(int* Pascal_tr, int current_level) {
	int* next_level = (int*)malloc(sizeof(int)*(current_level + 1));

	next_level[0] = Pascal_tr[0];
	for (int i = 1; i < current_level; i++) {
		next_level[i] = Pascal_tr[i - 1] + Pascal_tr[i];
	}
	next_level[current_level] = Pascal_tr[current_level - 1];
	free(Pascal_tr);
	return next_level;
}
