#include <stdio.h>
#include <stdlib.h>
char*str_concatenate(char*str1, char*str2);
int main(void) {
	char *str1;
	char *str2;
	
	int n1, n2;

	printf("Input size of str1 : ");
	scanf("%d", &n1);
	getchar();
	str1 = (char*)malloc(sizeof(char) * (n1+1));
	printf("str1 : ");
	
	for (int i = 0; i < n1; i++) {
		scanf("%c", &str1[i]);
	}
	str1[n1] = '\0';
	getchar();

	printf("Input size of str2 : ");
	scanf("%d", &n2);
	getchar();
	str2 = (char*)malloc(sizeof(char) * (n2+1));
	printf("str2 : ");
	
	for (int i = 0; i < n2; i++) {
		scanf("%c", &str2[i]);
	}
	str2[n2] = '\0';
	getchar();

	str1 = str_concatenate(str1, str2);
	printf("\n\nresult : %s", str1);
}
char*str_concatenate(char*str1, char*str2) {
	int n1, n2;
	int i;
	for (i = 0; ; i++) {
		if (str1[i] == '\0') break;
	}
	n1 = i;
	for (i = 0; ; i++) {
		if (str2[i] == '\0') break;
	}
	n2 = i;

	str1 = (char*)realloc(str1, (n1 + n2+3) * sizeof(char));
	str1[n1] = ' ';
	for (int k = 0; k < n2; k++) {
		str1[n1 + k + 1] = str2[k];
	}
	str1[n1 + n2 + 1] = '\n';
	str1[n1 + n2 + 2] = '\0';
	return str1;
}