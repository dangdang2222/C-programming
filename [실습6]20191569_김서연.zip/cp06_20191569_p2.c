#include <stdio.h>

char* getScientificFormatString(char* strPtr);

void main() {
	char temp[15], *p;

	printf("Input scientific format number : ");
	p = getScientificFormatString(temp);

	if (p == NULL)
		printf("|%-20s|\n", temp);
	else
		printf("|%20s|\n", p);

}

char* getScientificFormatString(char* strPtr) {
	char* p;
	scanf("%15[0123456789+-Ee.]", strPtr);

	p = strPtr;
	int flag1 = 0;
	/*
	TODO
	1) find location of  'e'(or 'E') by iterating p
	2) 'e'(or 'E') after '+'(or '-')
	3) '+'(or '-') after more than two digits
	*/
	for (int i = 0; i < 9; i++) {
		if (strPtr[i] == 'E' || strPtr[i] == 'e') {
			if (strPtr[i + 1] == '+' || strPtr[i + 1] == '-') {
				if (strPtr[i + 2] >= '0'&&strPtr[i + 2] <= '9') {
					if (strPtr[i + 3] >= '0'&&strPtr[i + 3] <= '9') {
						flag1 = 1;
						break;
					}
				}
			}
		}
	}

	if (flag1 == 1)
		return strPtr;
	else
		return NULL;


}