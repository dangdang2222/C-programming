#include <stdio.h>
#include <stdlib.h>

char* newMyString(int n);
void printMyString(char* my_str);
void fillMyString(char** my_str, char *input);

int main() {
	char *str = NULL;

	str = newMyString(9);
	fillMyString(&str, "CONFUCIUS");
	printMyString(str);

	fillMyString(&str, "HI");
	printMyString(str);

	fillMyString(&str, "ABCDEFGHIJKLMNOPQRSTUVWXYZ");
	printMyString(str);

	return 0;
}

char* newMyString(int n) {
	char* str;
	str = (char*)malloc(sizeof(char)*(n + 1));

	str[0] = n;
	return str;
}

void printMyString(char* my_str) {
	int i;
	int n = (int)my_str[0];
	/*
	TODO2. print
	1) length of string
	2) string value using for loop
	*/
	printf("(%d)", n);
	for (i = 1; i < n+1; i++) {
		printf("%c", my_str[i]);
	}
	printf("\n");

	return;
}

void fillMyString(char** my_str, char *input) {
	int len = 0, i;
	/* from class note slide 11 */

	char *ptr = input;
		for (i = 0; ; i++) {
			if (input[i] == '\0')
				break;
		}
	len = i;

	if (len != (int)(*my_str)[0]) {
		if (len > (*my_str)[0]) {
			(*my_str) = (char*)realloc((*my_str),sizeof(char)*(len + 1));
			(*my_str)[0] = len;
			for (int k = 0; k < len; k++) {
				(*my_str)[k + 1] = input[k];
			}

			//*my_str = ptr;
			return;
		}
	}

	//len=9 my_str[0]=9-->�ٵ�10��
	(*my_str)[0] = len;
	for (int k = 0; k < len; k++) {
		(*my_str)[k + 1] = input[k];
	}
	/*
	TODO5. fill string data
	*/

	return;
}