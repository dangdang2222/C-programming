#include <stdio.h>
void printByWord(char *str);
int main(void) {
	char input[41];
	printf("Input string : ");

	printByWord(input);

}

void printByWord(char *str) {
	
	int i;
	char c;

	for (i = 0; i < 40; i++) {
		scanf("%c", &c);
		if (c == '\n') break;
		str[i] = c;
	}
	str[i] = '\0';
	int k, p, q;

	printf("- Result -\n");

	if (str[0] < 65 || str[0]>90 && str[0] < 97 || str[0]>122) 
		printf("%40.20s", str);
	else {
		k = 0;
		for (p = k; p < i+1; p++) {
			if (str[p] == ' ' || str[p] == '\0') {
				printf("\t\t");
				for (q = k; q < p; q++) {
					printf("%c", str[q]);
				}
				printf("\n");
				k = p + 1;
			}

		}

	}

}