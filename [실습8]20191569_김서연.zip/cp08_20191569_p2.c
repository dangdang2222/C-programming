#include <stdio.h>

enum Date { sun = 0, mon, tue, wed, thu, fri, sat };
struct Calendar {
	int year, month, day;
	enum Date date;
	char* dateString;
};

enum Date getDate(int year, int month, int day) {
	if (month < 3) {
		year--;
		month += 12;
	}
	return (year + year / 4 - year / 100 + year / 400 + (13 * month + 8) / 5 + day) % 7;
}

char* getDayOfWeek(enum Date currDate) {
	char *p;

	switch (currDate) {
	case 0: p= "Sunday"; break;
	case 1: p = "Monday"; break;
	case 2: p = "Tuesday"; break;
	case 3: p = "Wednesday"; break;
	case 4:p = "Thursday"; break;
	case 5: p = "Friday"; break;
	case 6: p = "Saturday"; break;
	defualt: break;
	}

	return p;
}

int main() {
	struct Calendar today;

	printf("Input Year : ");
	scanf("%d", &(today.year));
	printf("Input Month : ");
	scanf("%d", &(today.month));
	printf("Input Day : ");
	scanf("%d", &(today.day));
	/*
	TODO1. input Year, Month, Day
	*/
	today.date = getDate(today.year, today.month, today.day);
	today.dateString = getDayOfWeek(today.date);

	printf("%4d-%02d-%02d is %s\n", today.year, today.month,
		today.day, today.dateString);
	return 0;
}
