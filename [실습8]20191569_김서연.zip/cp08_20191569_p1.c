#include <stdio.h>

struct CoinBox {
	int n500;
	int n100;
	int n50;
	int n10;
};

int main() {
	struct CoinBox change = { 0,0,0,0 };
	int Coins[4] = { 500, 100, 50, 10 };
	int Money;
	int i;
	printf("Input money : ");
	scanf("%d", &Money);

	for (i = 0; i <= 4; i++) {

		switch (i) {
		case 0: {
			if (Money / 500 != 0)
				change.n500 = Money / 500;
		}/*TODO2.*/; break;
		case 1: {
			if (Money / 100 != 0)
				change.n100 = Money / 100;
		}/*TODO3.*/; break;
		case 2: {
			if (Money / 50 != 0)
				change.n50 = Money / 50;
		} /*TODO4.*/; break;
		case 3: {
			if (Money / 10 != 0)
				change.n10 = Money / 10;
		} /*TODO5.*/; break;
		}
		Money = Money % Coins[i];
	}


	printf("# of 500 = %d\n", change.n500);
	printf("# of 100 = %d\n", change.n100);
	printf("# of 50 = %d\n", change.n50);
	printf("# of 10 = %d\n", change.n10);

	/*
	TODO6. print
	*/
	return 0;
}