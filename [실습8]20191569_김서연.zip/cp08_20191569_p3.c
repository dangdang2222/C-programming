#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#define M_PI 3.141592
typedef int* Vector_Components;
typedef int Component;
typedef double VectorSize;
typedef double Distance;
typedef int Scalar;
typedef double Angle;

typedef struct {
	Vector_Components comps;
	int vec_size;
}Vector;

VectorSize getSize(Vector v);
Distance getDistance(Vector v1, Vector v2);
Scalar getDotProduct(Vector v1, Vector v2);
Angle getAngle(Vector v1, Vector v2);

int main() {
	Vector v1, v2;
	int i;

	printf("Input size of Vector v1 : ");

	scanf("%d", &(v1.vec_size));
	v1.comps = (Vector_Components)malloc(sizeof(Component)*v1.vec_size);
	/*
	TODO1. input sizeof v1, memory allocation for vector components of v1
	*/
	printf("Input %d components of v1 : ", v1.vec_size);
	for (i = 0; i < v1.vec_size; i++)
		scanf("%d", &(v1.comps[i]));

	printf("Input size of Vector v2 : ");

	scanf("%d", &(v2.vec_size));
	v2.comps = (Vector_Components)malloc(sizeof(Component)*v2.vec_size);
	/*
	TODO2. input sizeof v2, memory allocation for vector components of v2
	*/
	printf("Input %d components of v2 : ", v2.vec_size);
	for (i = 0; i < v2.vec_size; i++)
		scanf("%d", &(v2.comps[i]));

	printf("\n\nResult\n");
	printf("Size of v1 = %.2lf\n", getSize(v1));
	printf("Size of v2 = %.2lf\n", getSize(v2));

	if (v1.vec_size == v2.vec_size) {
		printf("Distance between v1 and v2 = %.3lf\n", getDistance(v1, v2));
		printf("Dot Product v1 * v2 = %d\n", getDotProduct(v1, v2));
		printf("Angle between v1 and v2 = %.2lf\n", getAngle(v1, v2));
	}
	return 0;
}

VectorSize getSize(Vector v) {
	VectorSize sum = 0;
	int i;

	for (int i = 0; i < v.vec_size; i++) {
		sum += (v.comps[i] * v.comps[i]);
	}

	return sqrt(sum);
	/*
	TODO3.
	*/
}

Distance getDistance(Vector v1, Vector v2) {
	Distance d, sum = 0;
	int i;

	for (int i = 0; i < v1.vec_size; i++) {
		sum += (v1.comps[i] - v2.comps[i])* (v1.comps[i] - v2.comps[i]);
	}

	return sqrt(sum);
	/*

	TODO4.
	*/
}

Scalar getDotProduct(Vector v1, Vector v2) {
	Scalar sum = 0;
	int i;
	for (int i = 0; i < v1.vec_size; i++) {
		sum += (v1.comps[i] * v2.comps[i]);
	}

	return sum;
	/*
	TODO5.
	*/
}

Angle getAngle(Vector v1, Vector v2) {
	Angle a;
	VectorSize vs1, vs2;
	Scalar dotv1v2 = 0 ;

	vs1 = getSize(v1);
	vs2 = getSize(v2);

	int i;
	for (int i = 0; i < v1.vec_size; i++) {
		dotv1v2 += (v1.comps[i] * v2.comps[i]);
	}
	
	a = acos(dotv1v2 / (vs1*vs2));
	/*
	TODO6.
	*/

	return a * 180 / M_PI;
}
