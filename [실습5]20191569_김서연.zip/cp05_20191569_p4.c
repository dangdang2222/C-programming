#include <stdio.h>
#include <stdlib.h>
#include <time.h> 

int** transpose(int** matrix, int m, int n);
void printmatrix(int **mat, int m, int n);

int main() {
	int m, n, **mat;
	int i, j;

	srand(time(NULL));

	printf("Number of Rows : ");
	scanf("%d", &m);
	printf("Number of Cols : ");
	scanf("%d", &n);
	
	mat = (int**)malloc(sizeof(int*)*m);
	for (int i = 0; i < m; i++) {
		mat[i] = (int*)malloc(sizeof(int)*n);
	}

	srand(time(NULL));
	for (int i = 0; i < m; i++) {
		for (int k = 0; k < n; k++)
		{
			mat[i][k] = rand() % 100 + 1;
		}
	}

	printf("Before \n");
	printmatrix(mat, m, n);
	printf("After \n");
	printmatrix(transpose(mat, m, n), n, m);
	return 0;
}

int** transpose(int **mat, int m, int n) {
	int **p;
	int i, j;

	p = (int**)malloc(sizeof(int*)*n);
	for (int i = 0; i < n; i++) {
		p[i] = (int*)malloc(sizeof(int)*m);
	}

	for (int i = 0; i < n; i++) {
		for (int k = 0; k < m; k++)
		{
			p[i][k] = mat[k][i];
		}
	}

	return p;
}

void printmatrix(int **mat, int m, int n) {
	int i, j;
	
	for (int i = 0; i <m; i++) {
		for (int k = 0; k < n; k++)
		{
			printf("%5d ", mat[i][k]);
		}
		printf("\n");
	}
	printf("\n");
}
