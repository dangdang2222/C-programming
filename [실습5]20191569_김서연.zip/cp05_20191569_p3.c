#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define maxNPnum 10
#define maxCPnum 5
#define TRUE 1
#define FALSE 0

void addPatient(int *patientList, int newPatientNumber, int n);
int isValidPatientNumber(int patientNumber);

int main() {
	int cp, np;
	int** pList;	// two dimensional list for normal & critical patients
	int input;
	int i;


	pList = (int**)malloc(sizeof(int*) * 2);
	pList[0] = (int*)malloc(sizeof(int)*maxNPnum);//�Ϲ�
	pList[1] = (int*)malloc(sizeof(int) *maxCPnum);//��ȯ��
	cp = np = 0;

	while (1) {
		printf("Input the Patient Number(Quit=0) : ");
		scanf("%d", &input);
		if (input == 0) break;

		if (isValidPatientNumber(input)) {
			// Critical patient
			if (1100000 <= input && input <= 1299999) {
				if (cp == maxCPnum)
					printf("No more extra Critical Patient Numbers\n");
				else {
					cp++;
					addPatient(pList[1], input, cp);
					printf("Normally Added\n");
				}
			}
			// Normal patient
			else if (210000000 <= input && input <= 229999999) {
				if (np == maxCPnum)
					printf("No more extra Normal Patient Numbers\n");
				else {
					np++;
					addPatient(pList[0], input, np);
					printf("Normally Added\n");
				}
			}
		}
		else
			printf("Invalid Patient Number\n");
	}
	for (i = 0; i < cp; i++) {
		printf("\n  ��ȯ��\t%d", pList[1][i]);
	}
	for (i = 0; i < np; i++) {
		printf("\n�Ϲ�ȯ��\t%d", pList[0][i]);
	}

	return 0;
}

void addPatient(int *patientList, int newPatientNumber, int n) {
	patientList[n - 1] = newPatientNumber;
}

int isValidPatientNumber(int patientNumber) {
	int sum = 0;
	int check = 0;
	// Critical patient	
	if (1100000 <= patientNumber && patientNumber <= 1299999) {
		/*
		TODO5.
		*/
		check += patientNumber % 10;
		patientNumber /= 10;
		for (int i = 0; i < 6; i++) {
			sum += patientNumber % 10;
			patientNumber /= 10;
		}
		if (sum % 10 == check) return 1;
		else return 0;
	}
	// Normal patient
	else if (210000000 <= patientNumber && patientNumber <= 229999999) {
		/*
		TODO6.
		*/

		check += patientNumber % 10;
		patientNumber /= 10;
		check += (patientNumber % 10) * 10;
		patientNumber /= 10;
		for (int i = 0; i < 7; i++) {
			sum += patientNumber % 10;
			patientNumber /= 10;
		}
		if (sum % 100 == check) return 1;
		else return 0;
	}
	else
		return FALSE;
}
