#include <stdio.h>
#include <stdlib.h>
#define MAX 9999


int* merge(int* ary1, int size1, int* ary2, int size2);
int main(void) {
	int* ary1 = (int*)calloc(4, sizeof(int));
	int* ary2 = (int*)calloc(4, sizeof(int));
	int* ary3 = (int*)calloc(4, sizeof(int));
	int* temp;

	printf("Input 12 integer : ");
	for (int i = 0; i < 4; i++) {
		scanf("%d", &ary1[i]);
	}
	for (int i = 0; i < 4; i++) {
		scanf("%d", &ary2[i]);
	}
	for (int i = 0; i < 4; i++) {
		scanf("%d", &ary3[i]);
	}

	temp = merge(ary1, 4, ary2, 4);
	printf("\nAfter 1st sorting : ");
	for (int i = 0; i < 8; i++) {
		printf("%d ", temp[i]);
	}

	temp = merge(temp, 8, ary3, 4);
	printf("\nAfter 2nd sorting : ");
	for (int i = 0; i < 12; i++) {
		printf("%d ", temp[i]);
	}

}

int* merge(int* ary1, int size1, int* ary2, int size2) {
	int* result = (int*)malloc(sizeof(int) * (size1 + size2));


	int* flag1 = (int*)calloc(size1, sizeof(int));
	int* flag2 = (int*)calloc(size2, sizeof(int));

	for (int i = 0; i < size1 + size2; i++)
	{
		int min1 = MAX;
		int min2 = MAX;
		int p = 0, q = 0;
		for (int j = 0; j < size1; j++) {
			if (ary1[j] < min1 && flag1[j] != 1) {
				min1 = ary1[j];
				p = j;
			}
		}
		for (int j = 0; j < size2; j++) {
			if (ary2[j] < min2 && flag2[j] != 1) {
				min2 = ary2[j];
				q = j;
			}
		}
		if (min1 < min2) {
			result[i] = min1;
			flag1[p] = 1;
		}
		else {
			result[i] = min2;
			flag2[q] = 1;
		}

	}

	free(flag1);
	free(flag2);
	free(ary1);
	free(ary2);

	return result;
}