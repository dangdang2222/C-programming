#include <stdio.h>
#include <stdlib.h>


int main(void) {
	char*chArr = (char*)malloc(sizeof(char));

	int count =0;
	int size = 1;
	char c;
	printf("Input string : ");
	while (1) {
		scanf("%c", &c);
		if (c == '\n')
			break;
		
		count++;
		if (count > size) {
			size *= 2;
			chArr = (char*)realloc(chArr, sizeof(char)*size);
		}
		
		chArr[count-1] = c;
	}
	char temp;
	count--;

	for (int i = 0; i < count / 2; i++) {
		temp = chArr[i];
		chArr[i] = chArr[count - i];
		chArr[count - i] = temp;
	}

	printf("\nOutput string : ");
	for (int i = 0; i < count+1; i++) {
		printf("%c", chArr[i]);
	}
}