#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define MAX_NAME_SIZE 20

#define FLUSH while (getchar()!='\n') {}

typedef struct _Node {
	int st_id;
	char *st_name;
	struct _Node *link;
}Node;
Node *head = NULL;

Node * create_Node(Node *head, int id, char *name);

int main() {
	int id, i;
	char name[MAX_NAME_SIZE];

	Node *print_node;

	for (i = 0; i < 5; i++) {
		printf("%d Input student id : ", i + 1);
		scanf("%d", &id);
		FLUSH;

		printf("Input student name : ");
		scanf("%[^\n]", name);
		FLUSH;

		head = create_Node(head, id, name);
	}

	print_node = head;
	for (i = 0; i < 5; i++) {

		/*
		TODO5.
		*/
		printf("%d\t%s\n", print_node->st_id, print_node->st_name);
		print_node = print_node->link;
	}

	return 0;
}

Node * create_Node(Node *head, int id, char *name) {
	Node *new;
	Node *tmp;

	tmp = head;
	new = (Node *)malloc(sizeof(Node));
	new->st_name = (char *)malloc(sizeof(char)*MAX_NAME_SIZE);

	new->st_id = id;
	strcpy(new->st_name,name);
	new->link = NULL;
	/*
	TODO2. assign values to st_id, st_name, link
	*/
	if (head == NULL) {
		head = new;
	}
	/* TODO3. */

	else {
		for (tmp = head; tmp->link != NULL; tmp = tmp->link) {
		}

		tmp->link = new;
		/* TODO4. */
	}
	return head;
}
