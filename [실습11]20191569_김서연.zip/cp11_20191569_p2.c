#include<stdio.h>
#include<stdlib.h>

void InsertNodeAtFront(int a);
void InsertNodeAtBack(int b);
void DeleteNodeAtFront();
void DeleteNodeAtBack();
void PrintList();

typedef struct _NODE {
	int	DATA;
	struct _NODE	*LINK;
} NODE;

NODE *head;

int main()
{
	InsertNodeAtFront(10);
	InsertNodeAtFront(20);
	InsertNodeAtFront(30);

	InsertNodeAtBack(40);
	InsertNodeAtBack(50);
	PrintList();

	DeleteNodeAtFront();
	DeleteNodeAtFront();

	DeleteNodeAtBack();
	PrintList();

	return 0;
}

void InsertNodeAtFront(int a)
{
	NODE *pNew;

	pNew = (NODE*)malloc(sizeof(NODE));
	pNew->DATA = a;

	pNew->LINK = head;
	head = pNew;
	/*
	TODO1. pNew-> previous head
	*/
}
void InsertNodeAtBack(int b)
{
	NODE *pNew, *pPrev;
	pPrev = head;

	pNew = (NODE*)malloc(sizeof(NODE));
	pNew->DATA = b;
	pNew->LINK = NULL;

	if (head == NULL) {
		head = pNew;
	}
	else {
		for (pPrev = head; pPrev->LINK != NULL; pPrev = pPrev->LINK);

		pPrev->LINK = pNew;
	}
	/*
	TODO2. pPrev -> pNew -> end
	*/
}
void DeleteNodeAtFront()
{
	NODE* ptr;
	ptr = (NODE*)malloc(sizeof(NODE));

	ptr = head;
	head = head->LINK;
	ptr->LINK = NULL;

	/*	TODO3. */
	free(ptr);
}
void DeleteNodeAtBack()
{
	NODE* pCur;
	NODE* temp;
	pCur = (NODE*)malloc(sizeof(NODE));

	for (temp = head; temp->LINK->LINK != NULL; temp = temp->LINK);
	pCur = temp->LINK;
	temp->LINK = NULL;

	free(pCur);

}
void PrintList()
{
	NODE *pPrev;
	pPrev = head;
	while (pPrev!= NULL)
	{
		printf("%d ", pPrev->DATA);
		pPrev = pPrev->LINK;
	}
	printf("\n");

}

