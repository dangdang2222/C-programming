#define inf 0xffff
#include <math.h>
#include <stdio.h>
#include <stdlib.h>

typedef union {
	float f_exp;
	int i_exp;
}nVals;

typedef struct {
	float x;
	char flag;
	nVals exp;
}Values;

float power(Values v);

int main(void) {
	Values v;
	float temp;
	float res;
	printf("Enter a value for x: ");
	scanf("%f", &v.x);
	printf("Enter a value for n: ");
	scanf("%f", &temp);

	if (fmodf(temp, 1) != 0) {
		v.flag = 'f';
		v.exp.f_exp = temp;
	}
	else {
		v.flag = 'i';
		v.exp.i_exp = (int)temp;
	}
	/*
	TODO1. check if temp is integer or float
	put it into v.exp.i_exp if int, or ...
	*/
	res = power(v);

	if (res == inf) {
		printf("Error - Cannot raise a non-positive number to a floating-point power.\n");
	}
	else {
		printf("y = ");
		printf("%f\n", res);
	}
}

float power(Values v) {
	float res = 1;
	int i;
	if (v.flag == 'i') {
		for (i = 0; i < v.exp.i_exp; i++) {
			res *= v.x;
		}
		/* TODO2. */
	}
	else {
		/* TODO3. */
		if (v.x < 0) res = inf;
		else res = exp(v.exp.f_exp*log((double)v.x));
	}
	return res;
}