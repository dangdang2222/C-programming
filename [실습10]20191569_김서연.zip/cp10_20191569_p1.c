#include <stdio.h>
#include <stdlib.h>

typedef struct {
	float real;
	float imag;
} Complex;

void getComplexNum(Complex *c1, Complex *c2);
void getAddResult(Complex *c1, Complex *c2, Complex *res);
void getSubResult(Complex *c1, Complex *c2, Complex *res);
void getMultResult(Complex *c1, Complex *c2, Complex *res);
void getDivResult(Complex *c1, Complex *c2, Complex *res);

int main(void) {
	Complex c1;
	Complex c2;
	Complex res;

	getComplexNum(&c1, &c2);
	printf("Two complex number is: \n");
	printf("%.1f + (%.1f)i\n", c1.real, c1.imag);
	printf("%.1f + (%.1f)i\n", c2.real, c2.imag);

	getAddResult(&c1, &c2, &res);
	printf("Result of Addition: %.1f + (%.1f)i\n", res.real, res.imag);
	getSubResult(&c1, &c2, &res);
	printf("Result of Subtraction: %.1f + (%.1f)i\n", res.real, res.imag);
	getMultResult(&c1, &c2, &res);
	printf("Result of Multiplication: %.1f + (%.1f)i\n", res.real, res.imag);
	getDivResult(&c1, &c2, &res);
	printf("Result of Division: %.1f + (%.1f)i\n", res.real, res.imag);

	return 0;
}


void getComplexNum(Complex *c1, Complex *c2) {
	printf("1st complex [real|imaginary]: ");
	scanf("%f %f", &c1->real, &(*c1).imag);
	/*TODO1. */
	printf("2nd complex [real|imaginary]: ");
	scanf("%f %f", &c2->real, &(*c2).imag);
	/*TODO2. */
}

void getAddResult(Complex *c1, Complex *c2, Complex *res) {
	/*TODO3. add c1 and c2 into res */
	res->real = c1->real + c2->real;
	res->imag = c1->imag + c2->imag;
}
void getSubResult(Complex *c1, Complex *c2, Complex *res) {
	/*TODO3. sub c2 from c1 (c1-c2) */
	res->real = c1->real - c2->real;
	res->imag = c1->imag - c2->imag;
}
void getMultResult(Complex *c1, Complex *c2, Complex *res) {
	/*TODO4. mul c1 and c2 */
	res->real = (c1->real * c2->real) - (c1->imag * c2->imag);
	res->imag = (c1->imag * c2->real) + (c1->real * c2->imag);
}
void getDivResult(Complex *c1, Complex *c2, Complex *res) {
	/*TODO5. div c2 from c1 */
	res->real = ((c1->real*c2->real) + (c1->imag*c2->imag)) / ((c2->real*c2->real) + (c2->imag*c2->imag));
	res->imag = ((c1->imag*c2->real) - (c1->real*c2->imag)) / ((c2->real*c2->real) + (c2->imag*c2->imag));
}