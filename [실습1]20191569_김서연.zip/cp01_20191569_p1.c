#include <stdio.h>

int main(void) {
	int a, b, c, d;
	int* big = &a;
	int* small = &a;

	printf("Input 4 integer :");
	scanf("%d %d %d %d", &a, &b, &c, &d);

	if (*big < b) {
		big = &b;
	}
	if(*small>b) {
		small = &b;
	}

	if (*big < c) {
		big = &c;
	}
	if (*small > c) {
		small = &c;
	}

	if (*big < d) {
		big = &d;
	}
	if (*small > d) {
		small = &d;
	}

	printf("maximum value is %d\n", *big);
	printf("%d is stored at address %d\n", *big, big);
	printf("minimum value is %d\n", *small);
	printf("%d is stored at address %d\n", *small, small);
}