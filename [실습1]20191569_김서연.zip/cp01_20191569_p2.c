#include <stdio.h>

int main(void) {
	float a, b, c;
	float*x, *y;

	printf("Input m1 and m2 :");
	scanf("%f %f", &a, &b);
	x = &a;
	y = &b;

	c = (float)(2 * (*x)*(*y)) / ((*x) + (*y))*9.8;

	printf("\nTorque = %f\n", c);
}