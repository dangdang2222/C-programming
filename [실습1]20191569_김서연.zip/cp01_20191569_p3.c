#include <stdio.h>

int main(void) {
	float a, b, c;
	char o;
	float *x, *y;

	printf("Input operand 1 :");
	scanf("%f", &a);
	x = &a;
	printf("Input operand 2 :");
	scanf("%f", &b);
	y = &b;

	getchar();
	printf("\nInput operator : ");
	scanf("%c", &o);

	if (o == '+') {
		c = *x + *y;
	}
	else if (o == '-') {
		c = *x - *y;
	}
	else if (o == '*') {
		c = *x * *y;
	}
	else if (o == '/') {
		c = *x / *y;
	}

	printf("\n\nResult : %.2f\n", c);
}