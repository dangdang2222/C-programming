#include <stdio.h>
void input_integer(int*, int*arrSize);
void inverse_reorder(int*, int*arrSize);
int main(void) {
	int arr[100];
	int *p = arr;
	int size;

	printf("Array size = ? ");
	scanf("%d", &size);

	input_integer(p, &size);

	printf("\ninputted data : ");
	for (int i = 0; i < size; i++) {
		printf("%d ", *(p+i));
	}

	inverse_reorder(p, &size);

	printf("\nreversed data : ");
	for (int i = 0; i < size; i++) {
		printf("%d ", *(p+i));
	}
}
void input_integer(int*p, int*arrSize) {

	for (int i = 0; i < *arrSize; i++) {
		scanf("%d", &p[i]);
	}
}
void inverse_reorder(int*p, int*arrSize) {
	int temp;
	for (int i = 0; i < *arrSize/2; i++) {
		temp = *(p+i);
		*(p+i) = *(p+*arrSize - i - 1);
		*(p+*arrSize - i - 1) = temp;
	}
}