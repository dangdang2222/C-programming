#include <stdio.h>
void delete_char(char*, int, char);
int main(void) {
	char Arr[] = { 'C','-','P','R','O','G','R','A','M','M','E','R','2','\0'};
	char *p = Arr;
	int i;
	char c;
	for (i = 0; ; i++) {
		if (*(Arr+i) == '\0') break;
		printf("%c ", *(Arr+i));
	}
	printf("\n");
	printf("character for deletion = ");
	scanf("%c", &c);

	delete_char(p, i, c);

	for (i = 0; ; i++) {
		if (*(Arr+i) == '\0') break;
		printf("%c ", *(Arr+i));
	}
}

void delete_char(char* Arr, int i, char c) {
	for (int k = 0; k < i; k++) {
		if (c == *(Arr + k)) {
			for (int p = k; p < i-1; p++) {
				*(Arr+p) = *(Arr+p + 1);
			}
			*(Arr+i-1) = '\0';
		}
	}

}