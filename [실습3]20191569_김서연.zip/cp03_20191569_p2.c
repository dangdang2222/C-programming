#include <stdio.h>
void add_integer(int*Arr, int size);
int main(void) {
	int size = 10;
	int Arr[10] = { 1,11,23,35,47,59,67,75,83,95 };

	for (int i = 0; i < size; i++) {
		printf("%d ", *(Arr+i));
	}
	printf("\n");
	add_integer(Arr, size);

	for (int i = 0; i < size; i++) {
		printf("%d ", *(Arr + i));
	}
}

void add_integer(int*Arr, int size) {
	printf("input integer number : ");
	int a;
	scanf("%d", &a);

	for (int i = 0; i < size; i++) {
		if (a < *(Arr+i)) {
			for (int k = size - 2; k >=i; k--) {
				*(Arr+k + 1) = *(Arr+k);
			}
			*(Arr+i) = a;
		}
		if (a == *(Arr+i)) break;
	}
}