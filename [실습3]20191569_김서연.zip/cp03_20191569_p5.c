#include <stdio.h>
#include<stdlib.h> 


void multiple(int left[][5], int right[][5], int result[][5]);
int main(void) {
	int left[5][5];
	int right[5][5];
	int result[5][5];

	srand(20191569);

	for (int i = 0; i < 5; i++) {
		for (int j = 0; j < 5; j++) {
			*(*(left+i)+j) = rand() % 10;
		}
	}
	for (int i = 0; i < 5; i++) {
		for (int j = 0; j < 5; j++) {
			*(*(right + i) + j) = rand() % 10;
		}
	}

	multiple(left, right, result);


	for (int i = 0; i < 5; i++) {
		for (int j = 0; j < 5; j++) {
			printf("%d ", *(*(left + i) + j));
		}	printf("\t");
		for (int j = 0; j < 5; j++) {
			printf("%d ", *(*(right + i) + j));
		}			printf("\t");
		for (int j = 0; j < 5; j++) {
			printf("%4d ", *(*(result + i) + j));
		}			printf("\n");
	}

}
void multiple(int left[][5], int right[][5], int result[][5]) {
	int sum = 0;
	for (int i = 0; i < 5; i++) {
		for (int j = 0; j < 5; j++) {
			sum = 0;

			for (int p = 0; p < 5; p++) {
				sum += (*(*(left+i)+p) * *(*(right+p)+j));
			}

			*(*(result+i)+j) = sum;
		}
	}
}