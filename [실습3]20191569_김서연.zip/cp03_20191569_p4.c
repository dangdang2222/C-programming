#include <stdio.h>
void selection_sort(int*array, int* pwalk1, int*pwalk2, int*pwalk3);
int main(void) {
	int Arr[11];
	int a, b, c;
	printf("Input 10 integer numbers : ");
	for (int i = 0; i < 10; i++) {
		scanf("%d", &Arr[i]);
	}
	Arr[10] = '\0';
	printf("\n");

	selection_sort(Arr, &a, &b, &c);

	printf("Sorted Result : ");
	for (int i = 0; i < 10; i++) {
		printf("%d ", Arr[i]);
	}
}
void selection_sort(int*array, int* pwalk1, int*pwalk2, int*pwalk3) {
	int temp;

	
	for (pwalk1 = array; *(pwalk1+1)!='\0'; pwalk1++) {
		pwalk3 = pwalk1 + 1;
		for (pwalk2 = pwalk1 + 1; *(pwalk2+1)!='\0'; pwalk2++) {
			if (*pwalk3 > *pwalk2)
				pwalk3 = pwalk2;
		}
		temp = *pwalk3;
		*pwalk3 = *pwalk1;
		*pwalk1 = temp;
	}
}