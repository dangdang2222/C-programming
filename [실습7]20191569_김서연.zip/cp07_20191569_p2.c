#include <stdio.h>
#include <string.h>
#include <stdlib.h> 

char* new_strncpy(char **to_string, const char *from_string, int size) {
	int i, flag = 0;

	if (*to_string == NULL) {
		(*to_string) = (char*)malloc(sizeof(char)*(size+1));
		(*to_string)[size] = '\0';
	}
	else if ((int)strlen(*to_string) <= size) {
		(*to_string) = (char*)realloc((*to_string),sizeof(char)*(size + 1));
		(*to_string)[size] = '\0';
	}
	else {
		(*to_string)[size] = '\0';
	}
	if (size == 0)
		size = (int)strlen(from_string);

	strncpy(*to_string, from_string, size);

	return *to_string;
}

int main() {
	char *p = NULL;
	char input[31];
	int size;

	printf("input string : ");
	scanf("%30[^\n]", input);
	printf("input size = ");
	scanf("%d", &size);

	printf("before p = %s\n", p);
	new_strncpy(&p, input, size);
	printf("after p = %s\n", p);
	system("PAUSE");

	printf("before p = %s\n", p);
	new_strncpy(&p, "Hello", 5);
	printf("after p = %s\n", p);
	char *p2 = (char*)malloc(sizeof(char) * 2);
	char *p3 = (char*)malloc(sizeof(char) * 10);
	new_strncpy(&p2, "HELLO WORLD!", 5);
	new_strncpy(&p3, "I need OpenLab!" + 7, 10);

	printf("p2 = %s\n", p2);
	printf("p3 = %s\n", p3);
	return 0;
}
