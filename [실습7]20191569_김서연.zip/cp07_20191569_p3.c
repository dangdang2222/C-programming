#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#define STUDENT_ID_BASE 20191001


void sorting(char **list, int n) {
	char temp[60];
	char strN1[30], strN2[30];
	int i, j;

	for (i = 0; i < n - 1; i++) {
		for (j = i + 1; j < n; j++) {
			sscanf(list[i], "%30[^/]", strN1);
			sscanf(list[j], "%30[^/]", strN2);

			for (int k = 0; k < strlen(strN1); k++) {
				if (strN1[k] > strN2[k]) {
					strcpy(temp, list[i]);
					strcpy(list[i], list[j]);
					strcpy(list[j], temp);

					break;
				}
				else if (strN1[k] < strN2[k]) break;
			}
			/*
			TODO3. swap string by:
			1) comparing string data 'strN1', 'strN2'
			2) use variable 'temp'
			*/
		}
	}
}

double getAvg(char **list, int n) {
	int i, num, sum = 0;
	char name[31];
	char fm[7];

	for (i = 0; i < n; i++) {
		sscanf(list[i], "%30[^/]%*c %7[^ ] %*c %d", name, fm, &num);
		sum += num;
	}
	return (double)sum / n;
}

int main() {
	char** list;
	char temp[10];
	int i, n, bufsize = 60;
	FILE *fp;

	if (!(fp = fopen("student.dat", "r"))) {
		printf("\nError for opening student.dat file\n");
		return 100;
	}

	fgets(temp, sizeof(temp), fp);
	sscanf(temp, "%d", &n);
	/*
	TODO1. read student size from file
	1) read string(temp) from file by fgets() or etc
	2) get integer 'n' from 'temp' by sscanf
	*/

	//char ttemp[40];

	list = (char**)malloc(sizeof(char*)*n);
	for (i = 0; i < n; i++) {
		list[i] = (char*)malloc(sizeof(char) * 60);
	}

	for (i = 0; i < n; i++) {
		fgets(list[i], 60, fp);
	}
	/*
	TODO2. 'list' memory allocation & get info from file
	1) list is 2D char array
	2) one line per one student's info
	3) student's information each in the 'list' is string data(char*)
	4) read string(list[i]) from file by fgets() or etc
	*/
	fclose(fp);

	sorting(list, n);

	printf("-----Student List-----\n");
	for (i = 0; i < n; i++)
		printf("%d / %s", STUDENT_ID_BASE + i, list[i]);
	printf("---------------------\n");
	printf("average = %6.2lf\n", getAvg(list, n));

	for (i = 0; i < n; i++)
		free(list[i]);
	free(list);
	return 0;
}