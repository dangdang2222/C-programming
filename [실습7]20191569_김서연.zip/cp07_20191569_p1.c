#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void splitString(char *, char *, char *);

int main() {
	char *word1, *word2;
	char input[31];
	int n;
	printf("input str : ");
	scanf("%30[^\n]", input);

	n = (int)strlen(input) / 2;

	if (strlen(input) % 2 == 0) {
		word1 = (char*)malloc(sizeof(char)*(n+1));
		word2 = (char*)malloc(sizeof(char)*(n+1));
	}
	else {
		word1 = (char*)malloc(sizeof(char)*(n+1));
		word2 = (char*)malloc(sizeof(char)*(n+2));
	}
	/*
	TODO1. memory allocation to 'word1', 'word2'
	*/
	splitString(input, word1, word2);

	printf("[%s] -> [%s] [%s]\n", input, word1, word2);
	return 0;
}

void splitString(char *str, char *word1, char *word2) {
	int i, n = (int)strlen(str);

	strcpy(word1, str);
	word1[n / 2] = '\0';

	strcpy(word2, str + n / 2);
	/*
	TODO2. copy data to word1 first half of data, to word2 second half of data
	be aware of
	1) string size
	2) end of string ('\0')
	*/
}
